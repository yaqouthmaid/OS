
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import javax.swing.UIManager;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

public class GUI
{
    private JFrame frame;
    private JPanel mainPanel;
    private JScrollPane tablePane;
    private JButton addBtn;
    private JButton removeBtn;
    private JButton computeBtn;
    private JLabel wtLabel;
    private JLabel wtResultLabel;
    private JLabel tatLabel;
    private JLabel tatResultLabel;
    private JComboBox option;
    private JTable model;
    private JLabel lblWaitTime;
    private JLabel lblTurnAroundTime;
    private JLabel lblChoseMethod;
    private  JLabel thousd_wtt;
    private  JLabel thousd_wwt ;
    private  JLabel tenthouswtt;
    private JLabel tenthouswwt;
    
    public GUI()
    {
    String[] columnNames = {"Process", "AT", "BT", "WT", "TAT"};
    	
        tablePane = new JScrollPane();
        tablePane.setBounds(25, 25, 450, 131);

        Object[][] data = {
        	    {"1", "", "","", ""},
        	    {"2", "", "","", ""},
        	    {"3", "", "","", ""},
        	    {"4", "", "","", ""},
        	    {"5","", "", "", ""},
        	    {"6", "", "","", ""},
        	    {"7", "", "","", ""},
        	    {"8", "", "","", ""},

        	    
        	};
           
        wtLabel = new JLabel("AWWT");
        wtLabel.setHorizontalAlignment(SwingConstants.CENTER);
        wtLabel.setBounds(43, 367, 62, 25);
        tatLabel = new JLabel("AWTT");
        tatLabel.setHorizontalAlignment(SwingConstants.CENTER);
        tatLabel.setBounds(33, 331, 85, 25);
        wtResultLabel = new JLabel();
        wtResultLabel.setBounds(161, 377, 58, 25);
        tatResultLabel = new JLabel();
        tatResultLabel.setBounds(161, 331, 58, 25);
        
        option = new JComboBox(new String[]{"FCFS", "SRT",  "RR"});
        option.setModel(new DefaultComboBoxModel(new String[] {"FCFS", "SRT", "RR", "MFQ"}));
        option.setBounds(183, 231, 85, 20);
        
        computeBtn = new JButton("execute ");
        computeBtn.setBounds(327, 228, 85, 25);
        computeBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        computeBtn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String selected = (String) option.getSelectedItem();
                CPUScheduler scheduler;
                CPUScheduler scheduler_thousend;
                CPUScheduler scheduler_ten_tho;

                
                switch (selected) {
                    case "FCFS":
                        scheduler = new FirstComeFirstServe();
                        scheduler_thousend = new FirstComeFirstServe();
                        scheduler_ten_tho = new FirstComeFirstServe();

                        break;
                    
                    case "SRT":
                        scheduler = new ShortestRemainingTime();
                        scheduler_thousend = new ShortestRemainingTime();
                        scheduler_ten_tho = new ShortestRemainingTime();
                        
                        break;
                    case "MFQ":
                        scheduler = new RoundRobin();
                        scheduler_thousend = new RoundRobin();
                        scheduler_ten_tho = new RoundRobin();
                        
                        break;
                    case "RR":
                     
                        scheduler = new RoundRobin();
                        scheduler_thousend = new RoundRobin();
                        scheduler_ten_tho = new RoundRobin();
                        
                        scheduler.setTimeQuantum(10); 
                        scheduler_thousend.setTimeQuantum(10); 
                        scheduler_ten_tho.setTimeQuantum(10); 

                        break;
                    default:
                        return;
                }
                int at, bt;
                //------------------------------- 10 times-----------------------------------------------//
                for (int j =0 ; j<= 10 ; j++) {
                for (int i = 0; i < model.getRowCount(); i++)
                {
                    String process = (String) model.getValueAt(i, 0);
                    at = Integer.parseInt((String) model.getValueAt(i, 1));
                    bt = Integer.parseInt((String) model.getValueAt(i, 2));
                    int pl;
                    
            
                    
                    pl = 1;
                    
                                        
                    scheduler.add(new Row(process, at, bt, pl));
                

                }}
                
                scheduler.process();
        
                
                for (int i = 0; i < model.getRowCount(); i++)
                {
                    String process = (String) model.getValueAt(i, 0);
                    Row row = scheduler.getRow(process);
                    model.setValueAt(row.getWaitingTime(), i, 3);
                    model.setValueAt(row.getTurnaroundTime(), i, 4);
                }
                
                wtResultLabel.setText(Double.toString(scheduler.getAverageWaitingTime()));
                tatResultLabel.setText(Double.toString(scheduler.getAverageTurnAroundTime()));
                //--------------------------------------------------1000 times ------------------------------------//
                
                    for (int i = 0; i < model.getRowCount(); i++)
                    {
                        String process = (String) model.getValueAt(i, 0);
                        at = Integer.parseInt((String) model.getValueAt(i, 1))*12;
                        bt = Integer.parseInt((String) model.getValueAt(i, 2))*12;
                       int pl;                       
                        pl = 1;
                                      
                        scheduler_thousend.add(new Row(process, at, bt, pl));
                    }
                    
                    scheduler_thousend.process();
                    
                    thousd_wwt.setText(Double.toString(scheduler_thousend.getAverageWaitingTime()));
                    thousd_wtt.setText(Double.toString(scheduler_thousend.getAverageTurnAroundTime()));
                    //-------------------------------------100000 times ------------------------------------//
                   
                        for (int i = 0; i < model.getRowCount(); i++)
                        {
                            String process = (String) model.getValueAt(i, 0);
                             at = Integer.parseInt((String) model.getValueAt(i, 1))*12500;
                             bt = Integer.parseInt((String) model.getValueAt(i, 2))*12500;
                            int pl;
                            
                    
                            
                            pl = 1;
                            
                                                
                            scheduler_ten_tho.add(new Row(process, at, bt, pl));
                        }
                        
                        scheduler_ten_tho.process();
                        
                       
                        
                        tenthouswwt.setText(Double.toString(scheduler_ten_tho.getAverageWaitingTime()));
                        tenthouswtt.setText(Double.toString(scheduler_ten_tho.getAverageTurnAroundTime()));
                
            }
        });
        
        mainPanel = new JPanel(null);
        mainPanel.setBackground(Color.LIGHT_GRAY);
        mainPanel.setPreferredSize(new Dimension(500, 500));
        mainPanel.add(tablePane);
        model = new JTable(data, columnNames);
        model.setModel(new DefaultTableModel(
        	new Object[][] {
        		{"1", "1", "5", "", ""},
        		{"2", "2", "9", "", ""},
        		{"3", "6", "14", "", ""},
        		{"4", "10", "21", "", ""},
        		{"5", "13", "33", "", ""},
        		{"6", "16", "38", "", ""},
        		{"7", "19", "49", "", ""},
        		{"8", "20", "56", "", ""},
        	},
        	new String[] {
        		"Process", "AT", "BT", "WT", "TAT"
        	}
        ));
        tablePane.setColumnHeaderView(model);
        mainPanel.add(wtLabel);
        mainPanel.add(tatLabel);
        mainPanel.add(wtResultLabel);
        mainPanel.add(tatResultLabel);
        mainPanel.add(option);
        mainPanel.add(computeBtn);
        
        frame = new JFrame("CPU Scheduler Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.getContentPane().add(mainPanel);
        
        JLabel lblProcess = new JLabel("Process #");
        lblProcess.setBounds(25, 11, 70, 14);
        mainPanel.add(lblProcess);
        
        JLabel lblArrivalTime = new JLabel("Arrival time ");
        lblArrivalTime.setBounds(120, 11, 70, 14);
        mainPanel.add(lblArrivalTime);
        
        JLabel lblBt = new JLabel("service time ");
        lblBt.setBounds(211, 11, 79, 14);
        mainPanel.add(lblBt);
        
        lblWaitTime = new JLabel("wait time");
        lblWaitTime.setBounds(300, 11, 58, 14);
        mainPanel.add(lblWaitTime);
        
        lblTurnAroundTime = new JLabel("turn around time");
        lblTurnAroundTime.setBounds(385, 11, 105, 14);
        mainPanel.add(lblTurnAroundTime);
        
        lblChoseMethod = new JLabel("Chose Algorithm : ");
        lblChoseMethod.setBounds(54, 234, 105, 14);
        mainPanel.add(lblChoseMethod);
        
        JSeparator separator = new JSeparator();
        separator.setForeground(Color.BLACK);
        separator.setBounds(25, 364, 442, 2);
        mainPanel.add(separator);
        
        JSeparator separator_1 = new JSeparator();
        separator_1.setForeground(Color.BLACK);
        separator_1.setOrientation(SwingConstants.VERTICAL);
        separator_1.setBounds(128, 331, 12, 71);
        mainPanel.add(separator_1);
        
        JSeparator separator_2 = new JSeparator();
        separator_2.setForeground(Color.BLACK);
        separator_2.setOrientation(SwingConstants.VERTICAL);
        separator_2.setBounds(250, 331, 12, 71);
        mainPanel.add(separator_2);
        
        JSeparator separator_3 = new JSeparator();
        separator_3.setForeground(Color.BLACK);
        separator_3.setOrientation(SwingConstants.VERTICAL);
        separator_3.setBounds(368, 331, 7, 71);
        mainPanel.add(separator_3);
        
        JLabel lblTimes = new JLabel("10 times");
        lblTimes.setBounds(161, 307, 62, 14);
        mainPanel.add(lblTimes);
        
        JLabel lblTimes_1 = new JLabel("1000 times");
        lblTimes_1.setBounds(270, 307, 76, 14);
        mainPanel.add(lblTimes_1);
        
        JLabel lblTimes_2 = new JLabel("100000 times");
        lblTimes_2.setBounds(385, 307, 83, 14);
        mainPanel.add(lblTimes_2);
        
        thousd_wtt = new JLabel("");
        thousd_wtt.setBounds(260, 336, 105, 20);
        mainPanel.add(thousd_wtt);
        
         thousd_wwt = new JLabel("");
        thousd_wwt.setBounds(259, 372, 105, 20);
        mainPanel.add(thousd_wwt);
        
         tenthouswtt = new JLabel("");
        tenthouswtt.setBounds(379, 336, 111, 20);
        mainPanel.add(tenthouswtt);
        
         tenthouswwt = new JLabel("");
        tenthouswwt.setBounds(380, 367, 110, 20);
        mainPanel.add(tenthouswwt);
       
        frame.pack();
    }
    
    public static void main(String[] args)
    {
        new GUI();
    }
    
  
}
