import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class Interface {
	

	private JFrame frame;
	private JTextField textField;

	static int num, memory = 1000, ctr = 0, st = 0;
	static char proc[];
	static int size[];
	static int time[];

	static char procc[] = new char[] { '1', '2', '3', '4', '5', '6', '7', '8', '9', 't' };
	static int sizee[] = new int[] { 18, 77, 195, 430, 120, 132, 135, 139, 141, 155 };
	static int timee[] = new int[] { 4, 8, 10, 15, 13, 15, 17, 20, 21, 26 };
	int flagg[] = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	static int partion = 800;
	static int flag[];
	static int start[];
	static int end[];
	static char mem[] = new char[3];
	static int status[] = new int[3];
	 final static JTextArea textArea = new JTextArea();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface window = new Interface();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Interface() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		textArea.setText(" Output in Console ");
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Space for execution area :");
		lblNewLabel.setBounds(33, 34, 153, 20);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setText("800");
		textField.setBounds(185, 34, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(48, 119, 184, 14);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(48, 158, 184, 20);
		frame.getContentPane().add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setForeground(Color.BLACK);
		separator_2.setBounds(88, 99, 11, 165);
		frame.getContentPane().add(separator_2);
		
		JLabel lblProcess = new JLabel("process ");
		lblProcess.setBounds(34, 99, 65, 14);
		frame.getContentPane().add(lblProcess);
		
		JLabel label = new JLabel("1");
		label.setBounds(58, 132, 25, 14);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("2");
		label_1.setBounds(58, 175, 11, 14);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("3");
		label_2.setBounds(58, 212, 18, 14);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("4");
		label_3.setBounds(58, 250, 20, 14);
		frame.getContentPane().add(label_3);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setForeground(Color.BLACK);
		separator_3.setBounds(48, 200, 184, 14);
		frame.getContentPane().add(separator_3);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setForeground(Color.BLACK);
		separator_4.setBounds(48, 237, 184, 14);
		frame.getContentPane().add(separator_4);
		
		JLabel lblSize = new JLabel("size");
		lblSize.setBounds(109, 99, 46, 14);
		frame.getContentPane().add(lblSize);
		
		JLabel label_4 = new JLabel("18");
		label_4.setBounds(106, 132, 25, 14);
		frame.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("77");
		label_5.setBounds(109, 175, 25, 14);
		frame.getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("195");
		label_6.setBounds(109, 212, 25, 14);
		frame.getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("430");
		label_7.setBounds(109, 250, 25, 14);
		frame.getContentPane().add(label_7);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setOrientation(SwingConstants.VERTICAL);
		separator_5.setForeground(Color.BLACK);
		separator_5.setBounds(144, 99, 11, 165);
		frame.getContentPane().add(separator_5);
		
		JLabel lblTimeLimit = new JLabel("time limit");
		lblTimeLimit.setBounds(150, 99, 82, 14);
		frame.getContentPane().add(lblTimeLimit);
		
		JLabel label_8 = new JLabel("4");
		label_8.setBounds(171, 133, 25, 14);
		frame.getContentPane().add(label_8);
		
		JLabel label_9 = new JLabel("8");
		label_9.setBounds(170, 178, 25, 14);
		frame.getContentPane().add(label_9);
		
		JLabel label_10 = new JLabel("10");
		label_10.setBounds(172, 217, 25, 14);
		frame.getContentPane().add(label_10);
		
		JLabel label_11 = new JLabel("15");
		label_11.setBounds(173, 253, 25, 14);
		frame.getContentPane().add(label_11);
		
		JLabel lblNewLabel_1 = new JLabel("Ready queue : ");
		lblNewLabel_1.setBounds(33, 74, 98, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblOutput = new JLabel("Output : ");
		lblOutput.setBounds(281, 74, 98, 14);
		frame.getContentPane().add(lblOutput);
		
		JLabel lblJobQueue = new JLabel("Job queue(p#, size,time) : ");
		lblJobQueue.setBounds(33, 292, 163, 14);
		frame.getContentPane().add(lblJobQueue);
		
		JLabel lblP = new JLabel("p5,120,13");
		lblP.setBounds(184, 292, 98, 14);
		frame.getContentPane().add(lblP);
		
		JLabel lblP_1 = new JLabel("p6,132,15");
		lblP_1.setBounds(184, 306, 98, 14);
		frame.getContentPane().add(lblP_1);
		
		JLabel lblP_2 = new JLabel("p7,135,17");
		lblP_2.setBounds(184, 317, 98, 14);
		frame.getContentPane().add(lblP_2);
		
		JLabel lblP_3 = new JLabel("p8,139,20");
		lblP_3.setBounds(184, 331, 98, 14);
		frame.getContentPane().add(lblP_3);
		
		JLabel lblP_4 = new JLabel("p9,141,21");
		lblP_4.setBounds(184, 344, 98, 14);
		frame.getContentPane().add(lblP_4);
		
		JLabel lblP_5 = new JLabel("p10,155,26");
		lblP_5.setBounds(184, 355, 98, 14);
		frame.getContentPane().add(lblP_5);
		textArea.setBounds(269, 99, 277, 64);
		frame.getContentPane().add(textArea);
		frame.setBounds(100, 100, 587, 408);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		int maxtime, z, gflag = 0;
		num = 10;
		proc = new char[num];
		size = new int[num];
		time = new int[num];
		flag = new int[num];
		start = new int[num];
		end = new int[num];
		for (int i = 0; i < num; i++) {
			proc[i] = procc[i];
			size[i] = sizee[i];
			time[i] = timee[i];
			flag[i] = 0;
		}
		display();
		for (int i = 0; i < 10; i++) {
			if (memory < size[i]) {
				System.out.println("Skip, error");
				flag[i] = 1;
				continue;
			}
			allocate(i);
		}
		display();
		maxtime = findmaxtime();
		while (gflag == 0) {
			for (int i = 1; i <= maxtime; i++) {
				System.out.println("Time:- " + i);
				z = checktodeallocate(i);
				if (z == 1) {
					display();
					for (int k = 0; k < num; k++) {
						if (flag[k] == 0) {
							allocate(k);
							display();
						} else {
							gflag = 1;
						}
					}
				}
			}
		}
		
	}
	
	
	public static void allocate(int i) {
		int temp = 0;
		for (int j = 1; j <= 3; j++) {
			if (flag[i] == 0 && ctr < 3) {
				temp = partion * j;
				if (size[i] <= temp) {
					if (status[ctr] == 0) {
						for (int k = 1; k <= j; k++) {
							mem[k - 1] = proc[i];
							status[k - 1] = 1;
							ctr = ctr + (k);
						}
						start[i] = st;
						end[i] = st + temp;
						st = end[i];
						String t=" ";
						t = t+ "Process:= "+  proc[i] + " finished Ready queue p#" + proc[i + 1];
						System.out.println("Process:= " + proc[i] + " finished Ready queue p#" + proc[i + 1]);
						flag[i] = 1;
						break;
					}
				}
			}
			System.out.println(" Job queue: p#" + proc[i]);
		}
	}
	
	
	
	public static void display() {
		System.out.println("\nProcess\tTime\tSize\tEnd\tFlag");
		for (int i = 0; i < num; i++) {
			System.out.println(
					proc[i] + "\t" + time[i] + "\t" + size[i] +  "\t" + end[i] + "\t" + flag[i]);
		}
	}
	
	
	
	
	public static int findmaxtime() {
		int m = time[0];
		for (int i = 0; i < num; i++) {
			if (time[i] > m && flag[i] == 1) {
				m = time[i];
			}
		}
		return m;
	}
	
	
	
	public static int checktodeallocate(int t) {
		int flg = 0;
		for (int i = 0; i < num; i++) {
			if (time[i] == t) {
				flg = 1;
				if (start[i] == 0) {
					status[0] = 0;
					ctr = ctr - 1;
					st = 0;
					if (end[i] == 200) {
						status[1] = 0;
						ctr = ctr - 1;
					} else if (end[i] == 300) {
						status[2] = 0;
						ctr = ctr - 1;
					}
				} else if (start[i] == 100) {
					status[1] = 0;
					ctr = ctr - 1;
					st = 100;
					if (end[i] == 300) {
						status[2] = 0;
						ctr = ctr - 1;
					}
				} else if (start[i] == 200) {
					st = 200;
					ctr = ctr - 1;
					status[2] = 0;
				}
			}
		}
		return flg;
	}
}
